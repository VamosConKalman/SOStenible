"""hard_env.py — Simulador local del Modo Difícil (no se entrega).

Reproduce lo que describe el enunciado sobre el simulador oficial (starter_kit/environment.py):
pv × 12, batería 6.000 kWh / ±1.500 kW, vectores de precio y CO2 de solo 3 h,
meteo de la última hora en noves_dades_5min, cap_max_kwh y power_max_kw en el obs.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "starter_kit"))
from environment import CampusBatteryEnv  # noqa: E402
from prep_data import build_hourly  # noqa: E402

SPEC_HARD = {"capacity_kwh": 6000.0, "power_kw": 1500.0, "efficiency": 0.90, "soc_init": 0.50,
             "soc_min": 0.0, "soc_max": 1.0, "dt_hours": 1.0, "forecast_horizon": 3}
METEO_COLS = {
    "Atersa - IRRADIANCIA (W/m2)": "irradiancia_wm2",
    "Atersa - TEMPERATURA AMBIENTE (SENSOR 1) (ºC)": "temp_ambient_c",
    "Atersa - TEMPERATURA PANEL (SENSOR 1) (ºC)": "temp_panel_c",
    "Atersa - VELOCIDAD VIENTO (SENSOR 1) (m/s)": "vent_ms",
}


def load_hard_hourly(data_dir: Path | None = None) -> pd.DataFrame:
    data_dir = Path(data_dir or ROOT / "data" / "train")
    df = build_hourly(data_dir)
    m = pd.read_csv(data_dir / "meteo.csv", parse_dates=["Fecha"]).set_index("Fecha")
    m = m[list(METEO_COLS)].rename(columns=METEO_COLS).resample("1h").mean()
    df = df.join(m, how="left")
    df = df.asfreq("1h")
    df[["load_kw", "pv_kw", "precio_eur_per_kwh", "co2_kg_per_kwh"]] = (
        df[["load_kw", "pv_kw", "precio_eur_per_kwh", "co2_kg_per_kwh"]].interpolate(limit=3, limit_area="inside"))
    df[list(METEO_COLS.values())] = df[list(METEO_COLS.values())].interpolate(limit=3, limit_area="inside")
    df["pv_kw"] = df["pv_kw"] * 12.0
    return df


class HardEnv(CampusBatteryEnv):
    def __init__(self, hourly: pd.DataFrame, horizon: int = 3):
        self.horizon = horizon
        super().__init__(hourly, spec=SPEC_HARD)

    def _get_obs(self):
        obs = super()._get_obs()
        if obs is None:
            return None
        obs["preus_properes_24h"] = obs["preus_properes_24h"][: self.horizon]
        obs["co2_properes_24h"] = obs["co2_properes_24h"][: self.horizon]
        i = self.t - 1 if self.t > 0 else self.t
        row = self.df.iloc[i]
        for c in METEO_COLS.values():
            v = row.get(c, np.nan)
            obs["noves_dades_5min"][c] = float(v) if pd.notna(v) else 0.0
        obs["cap_max_kwh"] = self.cap
        obs["power_max_kw"] = self.power
        return obs


def semanas(df, d0, d1):
    cols = ["load_kw", "pv_kw", "precio_eur_per_kwh", "co2_kg_per_kwh"]
    out = []
    for (y, m), _ in df.groupby([df.index.year, df.index.month]):
        w = df.loc[pd.Timestamp(y, m, d0):pd.Timestamp(y, m, d1, 23)]
        if len(w) == 24 * (d1 - d0 + 1) and not w[cols].isna().any().any():
            out.append(w)
    return out


def score(ws, grids):
    A = pd.concat(ws)
    B = np.maximum(A.load_kw - A.pv_kw, 0)
    G = np.concatenate(grids)
    dco2 = 1 - (G * A.co2_kg_per_kwh.values).sum() / (B * A.co2_kg_per_kwh).sum()
    dcost = 1 - (G * A.precio_eur_per_kwh.values).sum() / (B * A.precio_eur_per_kwh).sum()
    return 100 * (0.7 * dco2 + 0.3 * dcost), 100 * dco2, 100 * dcost


def run_agent(make_agent, ws, horizon=3, pert=None):
    """Semanas reiniciadas, el mismo agente. Devuelve (score, co2, cost, infr, n_fail, s_total)."""
    import time
    agent = make_agent()
    grids, inf, tt = [], 0, 0.0
    for w in ws:
        env = HardEnv(w, horizon)
        obs, done = env._get_obs(), False
        while not done:
            o = pert(obs) if pert else obs
            t0 = time.perf_counter(); p = agent.act(o); tt += time.perf_counter() - t0
            obs, done = env.step(p)
        grids.append(np.asarray(env.grid)); inf += env.clipped + env.violations
    s, c, k = score(ws, grids)
    return s - inf, c, k, inf, getattr(agent, "n_fail", 0), tt


def run_actions(ws, acts):
    grids, inf = [], 0
    for w, a in zip(ws, acts):
        env = HardEnv(w)
        env._get_obs()
        for p in a:
            env.step(float(p))
        grids.append(np.asarray(env.grid)); inf += env.clipped + env.violations
    s, c, k = score(ws, grids)
    return s - inf, c, k, inf
