"""validar.py — Validación sin fuga: para cada ventana, perfiles ajustados SIN esa ventana."""
import subprocess, sys
from lab import make, run_agent, run_actions, semanas, DF, techo
import importlib
res = []
for d0, d1 in ((1, 7), (8, 14), (15, 21)):
    subprocess.run([sys.executable, "fit_perfiles.py", "--excluir", str(d0), str(d1)], check=True)
    ws = semanas(DF, d0, d1)
    r = run_agent(make(), ws)
    t = run_actions(ws, techo(ws))[0]
    res.append((d0, d1, len(ws), r, t))
    print(f"días {d0}-{d1} ({len(ws)} sem): agente {r[0]:.3f} (co2 {r[1]:.2f}, coste {r[2]:.2f}, infr {r[3]}, fail {r[4]}, {r[5]:.1f}s) | techo {t:.3f} | {100*r[0]/t:.0f} % del techo", flush=True)
subprocess.run([sys.executable, "fit_perfiles.py", "--todo"], check=True)
