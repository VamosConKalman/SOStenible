"""
agent.py — BatteryAgent para el Modo Difícil (MPC + LP HiGHS + previsiones).

Cada hora:
  1. Guarda lo observado: precio y CO2 de las horas que da el obs (3 h) y la medida de t-1.
  2. Prevé precio y CO2 de t+3..t+23 (ayer a la misma hora + perfiles de train con nivel actual),
     y la carga neta N = consumo − solar de t..t+23 (perfil + persistencia del residuo; solar con
     envolvente de cielo claro × índice de claridad que persiste).
  3. Resuelve un LP de 24 h con la restricción de importación g_k ≥ N̂_k + c_k − d_k en todas las horas
     y aplica solo la decisión de la hora actual, recortada a los límites físicos del obs.
Sin red, sin ficheros en act(): perfiles y parámetros se leen en __init__.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

import lp_model as lp

ONE_HOUR = pd.Timedelta(hours=1)
DAY = pd.Timedelta(hours=24)


def _num(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


class BatteryAgent:
    def __init__(self):
        path = Path(__file__).parent
        self.p = {
            "kappa": 0.5973, "w_co2": 0.7, "w_cost": 0.3, "eps": 0.5, "delta": 1e-6,
            "H": 24, "alpha_ayer": 0.0, "rho_nivel": 0.97, "peso_nivel_ahora": 1.0, "beta_ayer_load": 0.0,
            "z_net": 0.5, "sd_net0": 100.0, "sd_net_k": 5.0, "terminal_q": None,
            "corte": True, "e_max": 6000.0, "p_max": 1500.0,
            "week_hours": 168,    # si es un número: el bloque acaba week_hours después de su primera hora
        }
        try:
            self.p.update(json.loads((path / "parametres.json").read_text()))
        except Exception:
            pass
        self.prof = None
        try:
            P = json.loads((path / "perfils.json").read_text())
            self.prof = {k: (np.asarray(v, dtype=np.float64) if isinstance(v, list) else v) for k, v in P.items()}
            if "kappa" in P and "kappa" not in json.loads((path / "parametres.json").read_text() or "{}"):
                self.p["kappa"] = float(P["kappa"])
        except Exception:
            self.prof = None
        self._px = {}        # ts -> (precio, co2) observados
        self._meas = {}      # ts (inicio de hora medida) -> (load, pv)
        self._last_ts = None
        self._block_start = None
        self.n_fail = 0
        self.n_cortes = 0
        self.last_info = {}
        self.oracle = None   # SOLO para pruebas locales: dict con Series 'price', 'co2', 'net'

    # ------------------------------------------------------------------
    def act(self, obs):
        try:
            return float(self._act(obs))
        except Exception:
            self.n_fail += 1
            return 0.0

    # ------------------------------------------------------------------
    def _clim(self, key, ts):
        return float(self.prof[key][ts.month - 1, int(ts.dayofweek >= 5), ts.hour])

    def _remember(self, ts, preus, co2s, meas):
        for i in range(min(len(preus), len(co2s))):
            self._px[ts + i * ONE_HOUR] = (preus[i], co2s[i])
        if meas is not None:
            self._meas[ts - ONE_HOUR] = meas
        lim = ts - 2 * DAY
        if len(self._px) > 80:
            self._px = {k: v for k, v in self._px.items() if k >= lim}
        if len(self._meas) > 80:
            self._meas = {k: v for k, v in self._meas.items() if k >= lim}

    def _forecast_prices(self, ts, preus, co2s, H):
        n = min(len(preus), len(co2s))
        out_p, out_c = np.empty(H), np.empty(H)
        if self.prof is None:
            # sin perfiles: repetir el último valor conocido
            for k in range(H):
                out_p[k] = preus[min(k, n - 1)]; out_c[k] = co2s[min(k, n - 1)]
            return out_p, out_c
        cp = np.array([self._clim("price", ts + k * ONE_HOUR) for k in range(H)])
        cc = np.array([self._clim("co2", ts + k * ONE_HOUR) for k in range(H)])
        lp_ = np.mean(preus[:n]) / max(np.mean(cp[:n]), 1e-6)
        lc_ = np.mean(co2s[:n]) / max(np.mean(cc[:n]), 1e-6)
        g = self.p["peso_nivel_ahora"]
        if g < 1.0:
            sp = sc = cp24 = cc24 = 0.0
            for h, (pv_, cv_) in self._px.items():
                if ts - DAY <= h < ts:
                    sp += pv_; sc += cv_
                    cp24 += self._clim("price", h); cc24 += self._clim("co2", h)
            if cp24 > 0 and cc24 > 0:
                lp_ = g * lp_ + (1 - g) * sp / cp24
                lc_ = g * lc_ + (1 - g) * sc / cc24
        lp_ = float(np.clip(lp_, 0.4, 2.5)); lc_ = float(np.clip(lc_, 0.4, 2.5))
        a, rho = self.p["alpha_ayer"], self.p["rho_nivel"]
        for k in range(H):
            if k < n:
                out_p[k], out_c[k] = preus[k], co2s[k]
                continue
            dec = rho ** (k - n + 1)
            fp = cp[k] * (1 + (lp_ - 1) * dec)
            fc = cc[k] * (1 + (lc_ - 1) * dec)
            y = self._px.get(ts + k * ONE_HOUR - DAY)
            if y is not None:
                fp = a * y[0] + (1 - a) * fp
                fc = a * y[1] + (1 - a) * fc
            out_p[k], out_c[k] = fp, fc
        return out_p, out_c

    def _forecast_net(self, ts, meas, H):
        if self.prof is None:
            return None
        hrs = [ts + k * ONE_HOUR for k in range(H)]
        load = np.array([self._clim("load", h) for h in hrs])
        env = np.array([self._clim("pv_env", h) for h in hrs])
        ktm = float(self.prof["kt_mean"][ts.month - 1])
        # residuo de consumo de la última medida válida
        if meas is not None:
            r = meas[0] - self._clim("load", ts - ONE_HOUR)
            load = load + r * self.prof["phi_load"] ** np.arange(1, H + 1)
        b = self.p["beta_ayer_load"]
        if b > 0:
            for k, h in enumerate(hrs):
                y = self._meas.get(h - DAY)
                if y is not None and y[0] > 0:
                    load[k] = b * y[0] + (1 - b) * load[k]
        # claridad: última hora de sol medida (hoy) o media de ayer
        kt_now = None
        if meas is not None:
            e1 = self._clim("pv_env", ts - ONE_HOUR)
            if e1 > 100:
                kt_now = meas[1] / e1
        if kt_now is None:
            vals = []
            for h, (l, pv) in self._meas.items():
                if ts - DAY <= h < ts:
                    e = self._clim("pv_env", h)
                    if e > 100:
                        vals.append(pv / e)
            if vals:
                kt_now = float(np.mean(vals))
        kt = np.full(H, ktm)
        if kt_now is not None:
            kt = ktm + (min(max(kt_now, 0.0), 1.3) - ktm) * self.prof["phi_kt"] ** np.arange(1, H + 1)
        pv = env * np.clip(kt, 0.0, 1.3)
        net = load - pv
        z = self.p["z_net"]
        if z:
            net = net - z * (self.p["sd_net0"] + self.p["sd_net_k"] * np.arange(H))
        return net

    # ------------------------------------------------------------------
    def _act(self, obs):
        ts = pd.Timestamp(obs["timestamp"])
        soc = float(obs["soc_kwh"])
        e_max = _num(obs.get("cap_max_kwh")) or self.p["e_max"]
        p_max = _num(obs.get("power_max_kw")) or self.p["p_max"]
        preus = [float(x) for x in obs.get("preus_properes_24h", [])][:24]
        co2s = [float(x) for x in obs.get("co2_properes_24h", [])][:24]
        n = min(len(preus), len(co2s))
        if n == 0:
            return 0.0

        # medida de t-1 (solo si es la hora consecutiva y viene completa)
        meas = None
        prev, self._last_ts = self._last_ts, ts
        if prev is None or ts - prev != ONE_HOUR:
            self._block_start = ts            # primera hora de un bloque nuevo (salto en el tiempo)
        nd = obs.get("noves_dades_5min")
        if prev is not None and ts - prev == ONE_HOUR and isinstance(nd, dict):
            l, pv = _num(nd.get("ultim_consum_kw")), _num(nd.get("ultima_solar_kw"))
            if l is not None and pv is not None:
                meas = (l, pv)
        corte = meas is not None and meas[0] == 0.0 and meas[1] == 0.0
        self._remember(ts, preus, co2s, None if (meas is None or corte) else meas)

        # horizonte: 24 h salvo que los vectores avisen de fin de datos
        H = int(self.p["H"]) if n >= 3 else n
        is_end = n < 3
        wh = self.p["week_hours"]
        if wh:
            left = int((self._block_start + (int(wh) - 1) * ONE_HOUR - ts) / ONE_HOUR) + 1
            if left >= 1 and left <= H:
                H, is_end = left, True

        if self.oracle is not None and "price" in self.oracle:
            idx = [ts + k * ONE_HOUR for k in range(H)]
            pr = self.oracle["price"].reindex(idx).ffill().to_numpy()
            cr = self.oracle["co2"].reindex(idx).ffill().to_numpy()
        else:
            pr, cr = self._forecast_prices(ts, preus, co2s, H)
        w = self.p["w_co2"] * cr + self.p["w_cost"] * self.p["kappa"] * pr

        if self.oracle is not None and "net" in self.oracle:
            net = self.oracle["net"].reindex([ts + k * ONE_HOUR for k in range(H)]).to_numpy()
        else:
            net = self._forecast_net(ts, None if corte else meas, H)
        if corte and self.p["corte"]:
            if net is None:
                net = np.full(H, np.inf)
            net = np.array(net, dtype=np.float64)
            net[0] = 0.0
            self.n_cortes += 1

        V = 0.0
        q = self.p["terminal_q"]
        if q is not None and not is_end:
            V = lp.ETA_D * float(np.quantile(w, q))

        x = lp.solve_lp(w, soc, V, net=net, eps=self.p["eps"], delta=self.p["delta"], p_max=p_max, e_max=e_max)
        P = 0.0 if x is None else float(x[0] - x[H])
        P = lp.clamp(P, soc, p_max, e_max, self.p["eps"])
        self.last_info = {"H": H, "V": V, "P": P}
        return P
