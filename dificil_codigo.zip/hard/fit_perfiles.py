"""fit_perfiles.py — Ajusta los perfiles que usa el agente difícil y los guarda en src/perfils.json (local).

Uso:  python fit_perfiles.py              # excluye días 15-21 (para evaluar sin fuga)
      python fit_perfiles.py --todo       # todo train (para el zip final)
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).parent))
from hard_env import load_hard_hourly


def table(s, how="mean"):
    """(12 meses, 2 tipo de día, 24 h). Meses sin datos = media de los vecinos."""
    idx = s.index
    g = s.groupby([idx.month, (idx.dayofweek >= 5).astype(int), idx.hour])
    t = getattr(g, how)() if how in ("mean", "median") else g.quantile(how)
    out = np.full((12, 2, 24), np.nan)
    for (m, d, h), v in t.items():
        out[m - 1, d, h] = v
    for m in range(12):
        if np.isnan(out[m]).all():
            for dd in range(1, 6):
                near = [x for x in ((m - dd) % 12, (m + dd) % 12) if not np.isnan(out[x]).all()]
                if near:
                    out[m] = np.nanmean([out[x] for x in near], axis=0); break
    # huecos sueltos: media por hora del mismo mes y, si no, global
    glob = np.nanmean(out, axis=(0, 1))
    for m in range(12):
        for d in range(2):
            bad = np.isnan(out[m, d])
            if bad.any():
                alt = np.nanmean(out[m], axis=0)
                out[m, d, bad] = np.where(np.isnan(alt[bad]), glob[bad], alt[bad])
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--todo", action="store_true")
    ap.add_argument("--excluir", nargs=2, type=int, default=[15, 21]); a = ap.parse_args()
    df = load_hard_hourly()
    df = df[df.load_kw > 0]                                        # fuera cortes de datos
    if not a.todo:
        df = df[~df.index.day.isin(range(a.excluir[0], a.excluir[1] + 1))]
    P = {}
    P["price"] = table(df.precio_eur_per_kwh).tolist()
    P["co2"] = table(df.co2_kg_per_kwh).tolist()
    P["load"] = table(df.load_kw).tolist()
    env = table(df.pv_kw, 0.95)                                    # envolvente de cielo claro (pv ya ×12)
    env = np.maximum(env.max(axis=1, keepdims=True).repeat(2, axis=1), 0)  # igual laborable/finde
    P["pv_env"] = env.tolist()
    pv_mean = table(df.pv_kw); P["pv_mean"] = np.maximum(pv_mean, 0).tolist()
    # Persistencia del residuo de consumo (horas consecutivas reales)
    L = df.load_kw
    clim = np.array(P["load"])[L.index.month - 1, (L.index.dayofweek >= 5).astype(int), L.index.hour]
    r = (L - clim)
    consec = r.index.to_series().diff() == pd.Timedelta(hours=1)
    x, y = r.shift(1)[consec].values, r[consec].values
    P["phi_load"] = float(np.clip(np.dot(x, y) / np.dot(x, x), 0, 0.99))
    # Persistencia del índice de claridad kt = pv/env en horas de sol
    e = env[df.index.month - 1, 0, df.index.hour]
    kt = pd.Series(np.where(e > 100, df.pv_kw / np.where(e > 0, e, 1), np.nan), index=df.index)
    km = kt.groupby(kt.index.month).mean()
    P["kt_mean"] = [float(km.get(m, np.nanmean(kt))) for m in range(1, 13)]
    d = kt - np.array(P["kt_mean"])[kt.index.month - 1]
    ok = consec & d.notna() & d.shift(1).notna()
    P["phi_kt"] = float(np.clip(np.dot(d.shift(1)[ok], d[ok]) / np.dot(d.shift(1)[ok], d.shift(1)[ok]), 0, 0.99))
    B = np.maximum(df.load_kw - df.pv_kw, 0)
    P["kappa"] = float((B * df.co2_kg_per_kwh).sum() / (B * df.precio_eur_per_kwh).sum())
    out = Path(__file__).parent / "src" / "perfils.json"
    out.write_text(json.dumps(P))
    print(f"perfils.json ({'todo' if a.todo else f'sin días {a.excluir[0]}-{a.excluir[1]}'}): phi_load {P['phi_load']:.3f}  phi_kt {P['phi_kt']:.3f}  kappa {P['kappa']:.4f}  {out.stat().st_size/1024:.0f} KB")


if __name__ == "__main__":
    main()
