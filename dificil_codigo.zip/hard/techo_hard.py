"""Techo del modo difícil: LP semanal con todo conocido (pesos exactos del score agregado)."""
import numpy as np, pandas as pd
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

CAP, PMAX, EC, ED, EPS = 6000.0, 1500.0, 0.9 ** 0.5, 0.9 ** 0.5, 0.5


def techo(ws):
    A = pd.concat(ws); B = np.maximum(A.load_kw - A.pv_kw, 0)
    Eb, Cb = (B * A.co2_kg_per_kwh).sum(), (B * A.precio_eur_per_kwh).sum()
    acts = []
    for w in ws:
        N = (w.load_kw - w.pv_kw).to_numpy()
        wt = (0.7 * w.co2_kg_per_kwh / Eb + 0.3 * w.precio_eur_per_kwh / Cb).to_numpy(); wt = wt / wt.mean()
        T = len(N); nv = 4 * T
        c = np.r_[np.full(2 * T, 1e-6), np.zeros(T), wt]
        Ae = lil_matrix((T, nv)); be = np.zeros(T); be[0] = CAP / 2; Au = lil_matrix((T, nv))
        for t in range(T):
            Ae[t, 2 * T + t] = 1
            if t: Ae[t, 2 * T + t - 1] = -1
            Ae[t, t] = -EC; Ae[t, T + t] = 1 / ED
            Au[t, t] = 1; Au[t, T + t] = -1; Au[t, 3 * T + t] = -1
        r = linprog(c, A_ub=Au.tocsr(), b_ub=-N, A_eq=Ae.tocsr(), b_eq=be,
                    bounds=[(0, PMAX)] * 2 * T + [(EPS, CAP - EPS)] * T + [(0, None)] * T, method="highs")
        acts.append(r.x[:T] - r.x[T:2 * T])
    return acts
