"""robustez.py — El agente difícil frente a variaciones del obs (días 15-21)."""
import numpy as np, pandas as pd
from lab import make, run_agent, semanas, DF
ws = semanas(DF, 15, 21)
def drop(key):
    def f(o): o = dict(o); o.pop(key, None); return o
    return f
P = {
    "ninguna": None,
    "timestamp str": lambda o: dict(o, timestamp=pd.Timestamp(o["timestamp"]).isoformat()),
    "sin noves_dades": drop("noves_dades_5min"),
    "noves_dades = None": lambda o: dict(o, noves_dades_5min=None),
    "noves sin meteo": lambda o: dict(o, noves_dades_5min={k: v for k, v in o["noves_dades_5min"].items() if k in ("ultim_consum_kw", "ultima_solar_kw")}),
    "sin cap_max/power_max": lambda o: {k: v for k, v in o.items() if k not in ("cap_max_kwh", "power_max_kw")},
    "vectores float32": lambda o: dict(o, preus_properes_24h=list(np.float32(o["preus_properes_24h"])), co2_properes_24h=list(np.float32(o["co2_properes_24h"]))),
    "vectores de 24 h": "24",
}
for name, f in P.items():
    r = run_agent(make(), ws, horizon=24) if f == "24" else run_agent(make(), ws, pert=f)
    print(f"  {name:24s} score {r[0]:7.3f}  infr {r[3]}  n_fail {r[4]}  {r[5]:.1f}s", flush=True)
