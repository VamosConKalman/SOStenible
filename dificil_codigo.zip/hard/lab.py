"""lab.py — Experimentos del modo difícil (local)."""
import sys, json, importlib.util
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE / "src"))
from hard_env import load_hard_hourly, semanas, run_agent, run_actions
from techo_hard import techo
sys.path.insert(0, str(HERE / "src"))
_spec = importlib.util.spec_from_file_location("hard_agent", HERE / "src" / "agent.py")
A = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(A)

DF = load_hard_hourly()
ORA = {"price": DF.precio_eur_per_kwh, "co2": DF.co2_kg_per_kwh, "net": DF.load_kw - DF.pv_kw}


def make(oracle_keys=(), **params):
    def f():
        a = A.BatteryAgent(); a.p.update(params)
        if oracle_keys:
            a.oracle = {k: ORA[k] for k in oracle_keys}
        return a
    return f


if __name__ == "__main__":
    ws = semanas(DF, 15, 21)
    print("techo", round(run_actions(ws, techo(ws))[0], 3))
    for name, mk in [("E1 todo perfecto", make(("price", "co2", "net"))),
                     ("E2 precios perfectos, N prevista", make(("price", "co2"))),
                     ("E3 precios previstos, N perfecta", make(("net",))),
                     ("E4 todo previsto", make())]:
        r = run_agent(mk, ws)
        print(f"{name:34s} score {r[0]:7.3f}  co2 {r[1]:6.2f}  cost {r[2]:6.2f}  infr {r[3]}  fail {r[4]}  {r[5]:.1f}s")
