import sys, itertools
from lab import make, run_agent, semanas, DF
from concurrent.futures import ProcessPoolExecutor
WS = semanas(DF, 15, 21)

def job(args):
    name, keys, params = args
    r = run_agent(make(keys, **params), WS)
    return name, r[0], r[3], r[4]

def sweep(cfgs, workers=2):
    with ProcessPoolExecutor(workers) as ex:
        for name, s, inf, fail in ex.map(job, cfgs):
            print(f"  {name:45s} {s:7.3f}  infr {inf} fail {fail}", flush=True)

if __name__ == "__main__":
    grupo = sys.argv[1]
    if grupo == "H":
        cfgs = []
        for H in (24, 36, 48):
            for tq in (None, 0.3, 0.5):
                cfgs.append((f"E1 perfecto H={H} V_q={tq}", ("price", "co2", "net"), {"H": H, "terminal_q": tq}))
                cfgs.append((f"E4 previsto H={H} V_q={tq}", (), {"H": H, "terminal_q": tq}))
        sweep(cfgs)
    if grupo == "F":
        cfgs = [(f"alpha_ayer={a}", (), {"alpha_ayer": a}) for a in (0.0, 0.3, 0.8, 1.0)]
        cfgs += [(f"rho_nivel={r}", (), {"rho_nivel": r}) for r in (0.9, 0.99, 1.0)]
        cfgs += [(f"beta_ayer_load={b}", (), {"beta_ayer_load": b}) for b in (0.3, 0.6)]
        cfgs += [(f"z_net={z}", (), {"z_net": z}) for z in (-1.0, -0.5, 0.5, 1.0, 2.0)]
        sweep(cfgs)
    if grupo == "F2":
        cfgs = []
        for r in (0.97, 1.0):
            for z in (0.25, 0.5, 0.75):
                cfgs.append((f"alpha=0 rho={r} z={z}", (), {"alpha_ayer": 0.0, "rho_nivel": r, "z_net": z}))
        cfgs.append(("alpha=0.1 rho=1 z=0.5", (), {"alpha_ayer": 0.1, "rho_nivel": 1.0, "z_net": 0.5}))
        cfgs.append(("alpha=0 rho=1 z=0.5 + precios perfectos", ("price", "co2"), {"alpha_ayer": 0.0, "rho_nivel": 1.0, "z_net": 0.5}))
        cfgs.append(("alpha=0 rho=1 z=0 + N perfecta", ("net",), {"alpha_ayer": 0.0, "rho_nivel": 1.0}))
        sweep(cfgs)
    if grupo == "N":
        sweep([(f"peso_nivel_ahora={g}", (), {"peso_nivel_ahora": g}) for g in (1.0, 0.7, 0.4, 0.0)])
    if grupo == "W":
        sweep([(f"{n} week_hours={wh}", k, {"week_hours": wh})
               for wh in (None, 168) for n, k in (("E1 perfecto", ("price", "co2", "net")), ("E4 previsto", ()))])
